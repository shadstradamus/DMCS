# DMCS Python SDK

Python library for working with the Dynamic Multi-Dimensional Classification Standard (DMCS).

## Installation

The SDK is not published to PyPI yet. Install directly from the repository:

```bash
pip install "git+https://github.com/shadstradamus/DMCS.git#subdirectory=python-sdk"
```

Or clone the repo and install in editable mode:

```bash
git clone https://github.com/shadstradamus/DMCS.git
cd DMCS/python-sdk
pip install -e .
```

## Quick Start

```python
from dmcs_sdk import classification

# Load the classification
dmcs = classification()

# Get stats
print(dmcs.stats())
# {'version': '1.0.4', 'release_date': '2025-11-09', 'industries': 13, 'sectors': 55, 'subsectors': 191, ...}

# Lookup by ID
tech = dmcs.get_by_id('09')
print(tech)
# 09 — Technology (4 sectors, GIC)

saas = dmcs.get_by_id('09.01.002')
print(saas)
# 09.01.002 — Enterprise SaaS

# Search by text
results = dmcs.search('blockchain')
for result in results:
    print(result)
# 13 — Digital Assets & Blockchain (4 sectors, DIC)
# 13.01 — Blockchain Infra & Protocols (4 subsectors)
# ...

# Filter by classification
p_tax = dmcs.get_gic()  # Traditional economy (01-12)
d_tax = dmcs.get_dic()  # Digital assets (13)

print(f"GIC has {len(p_tax)} industries")
print(f"DIC has {len(d_tax)} industries")
```

## API Reference

### `classification`

Main class for loading and querying DMCS data.

**Methods:**
- `get_by_id(classification_id: str)` - Lookup industry, sector, or subsector by ID
- `search(query: str, case_sensitive: bool = False)` - Search classifications by label
- `filter_by_classification(classification: str)` - Get industries by GIC or DIC
- `get_gic()` - Get all GIC industries
- `get_dic()` - Get all DIC industries
- `stats()` - Get classification statistics

**Properties:**
- `total_industries` - Count of industries
- `total_sectors` - Count of sectors
- `total_subsectors` - Count of subsectors
- `version` - DMCS version
- `release_date` - Release date

### `Industry`

Represents a top-level industry classification.

**Attributes:**
- `id` - Industry ID (e.g., "09")
- `label` - Industry name
- `classification` - "GIC" or "DIC"
- `sectors` - List of Sector objects

**Methods:**
- `get_sector(sector_id: str)` - Get sector by ID

### `Sector`

Represents a sector within an industry.

**Attributes:**
- `id` - Sector ID (e.g., "09.01")
- `label` - Sector name
- `industry_id` - Parent industry ID
- `classification` - "GIC" or "DIC"
- `subsectors` - List of Subsector objects

**Methods:**
- `get_subsector(subsector_id: str)` - Get subsector by ID

### `Subsector`

Represents a subsector (most granular classification).

**Attributes:**
- `id` - Subsector ID (e.g., "09.01.002")
- `label` - Subsector name
- `sector_id` - Parent sector ID
- `industry_id` - Parent industry ID
- `classification` - "GIC" or "DIC"

## Examples

### Classify a company

```python
from dmcs_sdk import classification

dmcs = classification()

# Amazon: Primary = Online Marketplaces, Secondary = Cloud Platforms
primary = dmcs.get_by_id('04.05.002')
secondary = dmcs.get_by_id('09.01.004')

print(f"Amazon Primary: {primary}")
print(f"Amazon Secondary: {secondary}")
```

### Iterate through all classifications

```python
from dmcs_sdk import classification

dmcs = classification()

for industry in dmcs.industries:
    print(f"\n{industry}")
    for sector in industry.sectors:
        print(f"  {sector}")
        for subsector in sector.subsectors:
            print(f"    {subsector}")
```

### Find all blockchain-related classifications

```python
from dmcs_sdk import classification

dmcs = classification()

blockchain = dmcs.search('blockchain')
for item in blockchain:
    print(item)
```

## License

Apache 2.0 License - see [LICENSE](../LICENSE)
